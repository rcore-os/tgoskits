use core::sync::atomic::{AtomicU64, Ordering};

static CLEAR_COUNT: AtomicU64 = AtomicU64::new(0);
static CLEAR_OBSERVE_TOTAL_NS: AtomicU64 = AtomicU64::new(0);
static CLEAR_EXIT_TOTAL_NS: AtomicU64 = AtomicU64::new(0);
static PENDING_COUNT: AtomicU64 = AtomicU64::new(0);
static PENDING_OBSERVE_TOTAL_NS: AtomicU64 = AtomicU64::new(0);
static PENDING_UNMASK_TOTAL_NS: AtomicU64 = AtomicU64::new(0);

#[derive(Clone, Copy, Debug)]
pub struct QperfUserReturnSnapshot {
    pub clear_count: u64,
    pub clear_observe_total_ns: u64,
    pub clear_exit_total_ns: u64,
    pub pending_count: u64,
    pub pending_observe_total_ns: u64,
    pub pending_unmask_total_ns: u64,
}

pub fn qperf_user_return_snapshot() -> QperfUserReturnSnapshot {
    QperfUserReturnSnapshot {
        clear_count: CLEAR_COUNT.load(Ordering::Relaxed),
        clear_observe_total_ns: CLEAR_OBSERVE_TOTAL_NS.load(Ordering::Relaxed),
        clear_exit_total_ns: CLEAR_EXIT_TOTAL_NS.load(Ordering::Relaxed),
        pending_count: PENDING_COUNT.load(Ordering::Relaxed),
        pending_observe_total_ns: PENDING_OBSERVE_TOTAL_NS.load(Ordering::Relaxed),
        pending_unmask_total_ns: PENDING_UNMASK_TOTAL_NS.load(Ordering::Relaxed),
    }
}

pub(super) fn record(pending: bool, observe_ns: u64, exit_ns: u64) {
    let (count, observe_total, exit_total) = if pending {
        (
            &PENDING_COUNT,
            &PENDING_OBSERVE_TOTAL_NS,
            &PENDING_UNMASK_TOTAL_NS,
        )
    } else {
        (&CLEAR_COUNT, &CLEAR_OBSERVE_TOTAL_NS, &CLEAR_EXIT_TOTAL_NS)
    };
    observe_total.fetch_add(observe_ns, Ordering::Relaxed);
    exit_total.fetch_add(exit_ns, Ordering::Relaxed);
    count.fetch_add(1, Ordering::Relaxed);
}
